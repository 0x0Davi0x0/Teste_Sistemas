const calculadora = require("./calculadora");

test("Somar os dois números positivos", () => {
    expect(calculadora.soma(1, 2)).toBe(3);
})



test("Subtrair dois números", () => {
    expect(calculadora.subtrair(10, 5)).toBe(5);
    expect(calculadora.subtrair(0, 5)).toBe(-5);
    expect(calculadora.subtrair(5, 5)).toBe(0);
});

test("Dividir dois números", () => {
    expect(calculadora.dividir(10, 5)).toBe(2);
    expect(calculadora.dividir(0, 5)).toBe(0);
    expect(() => calculadora.dividir(10, 0)).toThrow("Erro: Divisão por zero");
});

test("Multiplicar dois números", () => {
    expect(calculadora.multiplicar(10, 5)).toBe(50);
    expect(calculadora.multiplicar(0, 5)).toBe(0);
    expect(calculadora.multiplicar(5, 5)).toBe(25);
});

